import"../chunks/disclose-version.oqRP3C1Q.js";import{T as t}from"../chunks/todoList.DVWdcMtX.js";function c(o){t(o,{completed:!0})}export{c as component};
