import{a as t}from"../chunks/entry.BD5mWX7W.js";export{t as start};
