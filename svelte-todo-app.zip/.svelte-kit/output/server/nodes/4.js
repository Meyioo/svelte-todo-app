

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.C_EX0Qzz.js","_app/immutable/chunks/disclose-version.oqRP3C1Q.js","_app/immutable/chunks/utils.D2gacb3q.js","_app/immutable/chunks/header.CnZBVx7m.js","_app/immutable/chunks/render.C9EJZr-N.js","_app/immutable/chunks/if.BbjJQ6Z5.js","_app/immutable/chunks/props.Cjk42cYo.js","_app/immutable/chunks/proxy.i-0w5mgg.js","_app/immutable/chunks/store.78GPTt41.js","_app/immutable/chunks/paths.yzEi79qW.js","_app/immutable/chunks/_todo.store.BwFdh1WA.js","_app/immutable/chunks/index.B6iX91I7.js","_app/immutable/chunks/input.2FLQekwo.js","_app/immutable/chunks/todoList.DVWdcMtX.js","_app/immutable/chunks/each.CbU1SPtY.js"];
export const stylesheets = [];
export const fonts = [];
