

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/todo-anlegen/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.D0Sgn62D.js","_app/immutable/chunks/disclose-version.oqRP3C1Q.js","_app/immutable/chunks/utils.D2gacb3q.js","_app/immutable/chunks/render.C9EJZr-N.js","_app/immutable/chunks/each.CbU1SPtY.js","_app/immutable/chunks/_todo.store.BwFdh1WA.js","_app/immutable/chunks/index.B6iX91I7.js","_app/immutable/chunks/input.2FLQekwo.js","_app/immutable/chunks/proxy.i-0w5mgg.js"];
export const stylesheets = [];
export const fonts = [];
