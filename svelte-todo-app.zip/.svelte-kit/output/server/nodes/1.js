

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.D-9tBs5b.js","_app/immutable/chunks/disclose-version.oqRP3C1Q.js","_app/immutable/chunks/utils.D2gacb3q.js","_app/immutable/chunks/render.C9EJZr-N.js","_app/immutable/chunks/stores.CGNK14UU.js","_app/immutable/chunks/entry.BD5mWX7W.js","_app/immutable/chunks/index.B6iX91I7.js","_app/immutable/chunks/paths.yzEi79qW.js","_app/immutable/chunks/store.78GPTt41.js"];
export const stylesheets = [];
export const fonts = [];
