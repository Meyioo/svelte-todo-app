import { C as attr, I as escape_html, B as pop, z as push, K as ensure_array_like, E as store_get, F as unsubscribe_stores } from "./index.js";
import { d as derived } from "./index2.js";
import { T as TodosStore, S as SearchStore } from "./_todo.store.js";
function TodoItem($$payload, $$props) {
  push();
  const { todo } = $$props;
  $$payload.out += `<div class="flex w-full justify-between border-b-2 p-2 text-left"><div class="flex">`;
  if (!todo.completed) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="me-4 ms-2 flex items-center"><input type="checkbox" class="size-4 rounded border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:ring-offset-gray-900" id="checkbox"${attr("checked", todo.selected, true)}></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div><strong class="font-medium text-gray-900">${escape_html(todo.title)}</strong> <p class="mt-1 text-pretty text-sm text-gray-700">${escape_html(todo.description)}</p></div></div> `;
  if (todo.deadline) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="text-sm text-gray-500">Fälligkeit: ${escape_html(new Date(todo.deadline).toLocaleDateString())}</div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div>`;
  pop();
}
function TodoList($$payload, $$props) {
  push();
  var $$store_subs;
  const { completed = false } = $$props;
  const todos = derived([TodosStore, SearchStore], ([$TodosStore, $SearchStore]) => {
    const todos2 = completed ? $TodosStore.completed : $TodosStore.open;
    return $SearchStore.length > 0 ? todos2.filter((todo) => todo.title.toLowerCase().includes($SearchStore.toLowerCase()) || todo.description.toLowerCase().includes($SearchStore.toLowerCase())) : todos2;
  });
  const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$todos", todos));
  $$payload.out += `<main><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let todo = each_array[$$index];
    TodoItem($$payload, { todo });
  }
  $$payload.out += `<!--]--> `;
  if (store_get($$store_subs ??= {}, "$todos", todos).length === 0) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<p class="mt-3 text-center text-gray-500">Keine Aufgaben gefunden</p>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></main>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
export {
  TodoList as T
};
