import { C as attr, I as escape_html, E as store_get, F as unsubscribe_stores, G as stringify } from "./index.js";
import { b as base } from "./paths.js";
import { S as SearchStore } from "./_todo.store.js";
function Button_link($$payload, $$props) {
  const { href, label } = $$props;
  $$payload.out += `<a${attr("href", href)} class="inline-block w-full rounded-lg bg-blue-700 px-5 py-3 text-sm font-medium text-white">${escape_html(label)}</a>`;
}
function Searchbar($$payload) {
  var $$store_subs;
  $$payload.out += `<div class="relative mx-3 mb-3"><label for="search" class="sr-only">Neue Aufgabe hinzufügen</label> <input type="text" id="search" placeholder="Suche nach..."${attr("value", store_get($$store_subs ??= {}, "$SearchStore", SearchStore))} class="w-full rounded-md border-gray-200 py-2.5 pe-10 shadow-sm sm:text-sm"> <span class="absolute inset-y-0 end-0 grid w-10 place-content-center"><button type="button" class="text-gray-600 hover:text-gray-700"><span class="sr-only">Search</span> <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-4"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path></svg></button></span></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
}
function Header($$payload, $$props) {
  const { title, showSearch = false } = $$props;
  $$payload.out += `<header class="sticky top-0 w-full border-b border-gray-200 bg-gray-50"><div class="mx-auto max-w-screen-xl px-3 py-8 sm:px-6 sm:py-12 lg:px-8"><div class="flex justify-between gap-4 md:flex-row md:items-center md:justify-between"><div><h1 class="text-2xl font-bold text-gray-900 sm:text-3xl">${escape_html(title)}</h1></div> <div class="flex items-center gap-4">`;
  Button_link($$payload, {
    href: `${stringify(base)}/todo-anlegen`,
    label: "Neu"
  });
  $$payload.out += `<!----></div></div></div> `;
  if (showSearch) {
    $$payload.out += "<!--[-->";
    Searchbar($$payload);
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></header>`;
}
export {
  Header as H
};
