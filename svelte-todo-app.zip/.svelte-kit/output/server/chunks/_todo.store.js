import { w as writable } from "./index2.js";
class TodoStore {
  open = [];
  completed = [];
}
function createPersistedStore(key, initialValue) {
  {
    return writable(new TodoStore());
  }
}
const TodosStore = createPersistedStore();
const SearchStore = writable("");
function addTodo(todo) {
  TodosStore?.update((store) => {
    store.open.push(todo);
    return store;
  });
}
export {
  SearchStore as S,
  TodosStore as T,
  addTodo as a
};
