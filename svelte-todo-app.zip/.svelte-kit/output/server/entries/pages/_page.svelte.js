import { H as Header } from "../../chunks/header.js";
import { T as TodoList } from "../../chunks/todoList.js";
function _page($$payload) {
  const completed = false;
  $$payload.out += `<div>`;
  Header($$payload, { title: "Offene Aufgaben", showSearch: true });
  $$payload.out += `<!----> `;
  TodoList($$payload, { completed });
  $$payload.out += `<!----></div>`;
}
export {
  _page as default
};
