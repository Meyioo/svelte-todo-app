import { T as TodoList } from "../../../chunks/todoList.js";
function _page($$payload) {
  const completed = true;
  TodoList($$payload, { completed });
}
export {
  _page as default
};
