import { C as attr, E as store_get, F as unsubscribe_stores, B as pop, G as stringify, z as push } from "../../chunks/index.js";
import { b as base } from "../../chunks/paths.js";
import { p as page } from "../../chunks/stores.js";
import { d as derived } from "../../chunks/index2.js";
import { T as TodosStore } from "../../chunks/_todo.store.js";
/* empty css               */
function Nav($$payload, $$props) {
  push();
  var $$store_subs;
  const selected = derived(TodosStore, (store) => store.open.some((todo) => todo.selected));
  $$payload.out += `<div class="sticky bottom-0 w-full pt-5"><div class="mx-auto w-full"><div class="bg-white px-7 shadow-lg"><div class="flex"><div class="group flex-1"><a${attr("href", `${stringify(base)}/`)} class="mx-auto flex w-full items-end justify-center border-b-2 border-transparent px-4 pt-2 text-center text-gray-500"><span class="block px-1 pb-2 pt-1"><i class="far fa-list mb-1 block pt-1 text-2xl"></i> <span class="block pb-1 text-xs">Offen</span></span></a></div> `;
  if (store_get($$store_subs ??= {}, "$page", page).route.id === "/") {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="group m-auto flex-1"><button class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-blue-700 text-white disabled:bg-blue-500" aria-label="Check"${attr("disabled", !store_get($$store_subs ??= {}, "$selected", selected), true)}><i class="fas fa-check"></i></button></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div class="group flex-1"><a${attr("href", `${stringify(base)}/abgeschlossen`)} class="mx-auto flex w-full items-end justify-center border-b-2 border-transparent px-4 pt-2 text-center text-gray-500"><span class="block px-1 pb-2 pt-1"><i class="fas fa-clipboard-check mb-1 block pt-1 text-2xl"></i> <span class="block pb-1 text-xs">Abgeschlossen</span></span></a></div></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function _layout($$payload, $$props) {
  push();
  const { children } = $$props;
  $$payload.out += `<div class="flex h-screen flex-col justify-between">`;
  children($$payload);
  $$payload.out += `<!----> `;
  Nav($$payload);
  $$payload.out += `<!----></div>`;
  pop();
}
export {
  _layout as default
};
