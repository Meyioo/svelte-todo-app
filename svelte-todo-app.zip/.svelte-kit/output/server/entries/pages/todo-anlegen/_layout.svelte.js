import { B as pop, z as push } from "../../../chunks/index.js";
import { H as Header } from "../../../chunks/header.js";
/* empty css                  */
function _layout($$payload, $$props) {
  push();
  const { children } = $$props;
  $$payload.out += `<div class="container">`;
  Header($$payload, { title: "Aufgabe anlegen" });
  $$payload.out += `<!----> `;
  children($$payload);
  $$payload.out += `<!----></div>`;
  pop();
}
export {
  _layout as default
};
