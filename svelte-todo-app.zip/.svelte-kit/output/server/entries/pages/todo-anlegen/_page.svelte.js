import { C as attr, I as escape_html, K as ensure_array_like, B as pop, z as push } from "../../../chunks/index.js";
import { a as addTodo } from "../../../chunks/_todo.store.js";
import { w as writable } from "../../../chunks/index2.js";
function Button($$payload, $$props) {
  const { type, onclick, label, disabled } = $$props;
  $$payload.out += `<button class="inline-block w-full rounded-lg bg-blue-700 px-5 py-3 text-sm font-medium text-white disabled:bg-blue-500"${attr("type", type)}${attr("disabled", disabled, true)}>${escape_html(label)}</button>`;
}
const ToastStore = writable("");
function showToast(message) {
  ToastStore.set(message);
}
function _page($$payload, $$props) {
  push();
  const todo = {
    title: "",
    description: "",
    completed: false,
    selected: false
  };
  const fields = [
    {
      name: "title",
      placeholder: "Titel eingeben",
      type: "text"
    },
    {
      name: "description",
      placeholder: "Beschreibung hinzufügen",
      type: "text"
    },
    {
      name: "deadline",
      placeholder: "Fälligkeitsdatum",
      type: "date"
    }
  ];
  function submit() {
    showToast("Formular erfolgreich abgeschickt!");
    addTodo(todo);
  }
  const each_array = ensure_array_like(fields);
  $$payload.out += `<div class="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8"><form class="mx-auto mt-4 max-w-md space-y-4"><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let field = each_array[$$index];
    $$payload.out += `<div><label${attr("for", field.name)} class="sr-only">${escape_html(field.placeholder)}</label> <div class="relative"><input${attr("type", field.type)}${attr("name", field.name)} class="w-full rounded-lg border-gray-200 p-4 pe-12 text-sm shadow-sm"${attr("placeholder", field.placeholder)}${attr("value", todo[field.name])}></div></div>`;
  }
  $$payload.out += `<!--]--> <div class="flex items-center justify-between">`;
  Button($$payload, {
    label: "Aufgabe anlegen",
    type: "button",
    disabled: !todo.title || !todo.description,
    onclick: submit
  });
  $$payload.out += `<!----></div></form></div>`;
  pop();
}
export {
  _page as default
};
