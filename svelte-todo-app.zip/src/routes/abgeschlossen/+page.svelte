<script lang="ts">
	import TodoList from '$lib/components/todoList.svelte';

	const completed = true;
</script>

<TodoList {completed} />

<style>
</style>
